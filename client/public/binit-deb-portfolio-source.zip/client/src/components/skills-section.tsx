import { useEffect, useRef } from "react";

export function SkillsSection() {
  const skillsRef = useRef<HTMLDivElement>(null);

  const skills = [
    { name: "JavaScript", level: 90, color: "bg-indigo-600" },
    { name: "React / Next.js", level: 88, color: "bg-blue-600" },
    { name: "Node.js", level: 85, color: "bg-green-600" },
    { name: "Python", level: 80, color: "bg-yellow-600" },
    { name: "HTML / CSS", level: 95, color: "bg-orange-600" },
    { name: "MySQL / DBMS", level: 78, color: "bg-purple-600" },
    { name: "Data Structures", level: 82, color: "bg-gray-600" },
    { name: "Data Analytics", level: 75, color: "bg-cyan-600" },
  ];

  const technologies = [
    { name: "React", icon: "⚛️" },
    { name: "Node.js", icon: "💚" },
    { name: "Next.js", icon: "🔺" },
    { name: "Python", icon: "🐍" },
    { name: "JavaScript", icon: "💛" },
    { name: "HTML/CSS", icon: "🎨" },
    { name: "MySQL", icon: "🗄️" },
    { name: "MongoDB", icon: "🍃" },
    { name: "Git", icon: "📝" },
    { name: "MS Excel", icon: "📊" },
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const skillBars = entry.target.querySelectorAll(".skill-bar");
            skillBars.forEach((bar, index) => {
              setTimeout(() => {
                bar.classList.add("animate");
              }, index * 200);
            });
            observer.unobserve(entry.target);
          }
        });
      },
      {
        threshold: 0.3,
        rootMargin: "0px 0px -100px 0px",
      }
    );

    if (skillsRef.current) {
      observer.observe(skillsRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section id="skills" className="py-20 bg-background theme-transition">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">
            Skills & Expertise
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            A comprehensive overview of my technical skills and proficiency
            levels across various technologies.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <img
              src="https://images.unsplash.com/photo-1517077304055-6e89abbf09b0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
              alt="Technical skills visualization showing programming languages and development tools on multiple screens"
              className="rounded-xl shadow-lg w-full h-auto"
            />
          </div>

          <div className="space-y-8" ref={skillsRef}>
            <h3 className="text-2xl font-bold text-foreground">
              Technical Proficiency
            </h3>

            <div className="space-y-6">
              {skills.map((skill, index) => (
                <div key={index} className="skill-item">
                  <div className="flex justify-between mb-2">
                    <span className="text-foreground font-medium">
                      {skill.name}
                    </span>
                    <span className="text-muted-foreground text-sm">
                      {skill.level}%
                    </span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-3">
                    <div
                      className={`skill-bar ${skill.color} h-3 rounded-full`}
                      style={{ width: `${skill.level}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Technology Stack */}
        <div className="mt-20">
          <h3 className="text-2xl font-bold text-foreground text-center mb-12">
            Technology Stack
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
            {technologies.map((tech, index) => (
              <div
                key={index}
                className="flex flex-col items-center space-y-2 p-4 bg-muted rounded-lg hover:bg-muted/80 transition-all"
              >
                <div className="text-4xl">{tech.icon}</div>
                <span className="text-foreground font-medium">{tech.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
